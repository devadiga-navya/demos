# Hackathon Repository Cloner PowerShell Script
# Run this script to clone all hackathon repositories

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "    Hackathon Repository Cloner" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Python is available
try {
    $pythonVersion = python --version 2>&1
    Write-Host "✅ Python found: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ ERROR: Python is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install Python 3.7+ and try again" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if repository_links.csv exists
if (-not (Test-Path "repository_links.csv")) {
    Write-Host "❌ ERROR: repository_links.csv not found!" -ForegroundColor Red
    Write-Host "Please run quick_setup.py first to create repositories." -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "✅ repository_links.csv found" -ForegroundColor Green
Write-Host ""

# Count repositories in CSV
try {
    $csvContent = Import-Csv "repository_links.csv"
    $repoCount = $csvContent.Count
    Write-Host "📁 Found $repoCount repositories to clone" -ForegroundColor Blue
} catch {
    Write-Host "⚠️  Warning: Could not read CSV file" -ForegroundColor Yellow
    $repoCount = "unknown"
}

Write-Host ""
Write-Host "Starting repository cloning..." -ForegroundColor Green
Write-Host ""

# Run the Python script
try {
    python clone_all_repositories.py
    $exitCode = $LASTEXITCODE
} catch {
    Write-Host "❌ Error running Python script: $_" -ForegroundColor Red
    $exitCode = 1
}

Write-Host ""
if ($exitCode -eq 0) {
    Write-Host "✅ Script completed successfully!" -ForegroundColor Green
} else {
    Write-Host "❌ Script completed with errors (exit code: $exitCode)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Press Enter to exit..."
Read-Host
