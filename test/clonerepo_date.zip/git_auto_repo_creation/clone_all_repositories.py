#!/usr/bin/env python3
"""
Clone All Hackathon Repositories Script

This script clones all repositories created by the quick_setup.py script
using the repository_links.csv file.
"""

import os
import sys
import csv
import time
import logging
import subprocess
import threading
import random
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('clone_repositories.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class RepositoryCloner:
    def __init__(self, csv_file='repository_links.csv', output_dir='repositories', max_workers=3):
        """
        Initialize the repository cloner.
        
        Args:
            csv_file (str): Path to the CSV file containing repository links
            output_dir (str): Directory to clone repositories into
            max_workers (int): Maximum number of concurrent clone operations (reduced for stability)
        """
        self.csv_file = csv_file
        self.output_dir = Path(output_dir)
        self.max_workers = max_workers
        self.repositories = []
        self.successful_clones = 0
        self.failed_clones = 0
        self.skipped_clones = 0
        self.retry_count = 0
        
        # Create output directory if it doesn't exist
        self.output_dir.mkdir(exist_ok=True)
        
        # Load repositories from CSV
        self.load_repositories()
    
    def load_repositories(self):
        """Load repository information from the CSV file."""
        try:
            if not os.path.exists(self.csv_file):
                logger.error(f"CSV file not found: {self.csv_file}")
                return
            
            with open(self.csv_file, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    self.repositories.append({
                        'team_name': row['team_name'],
                        'repository_name': row['repository_name'],
                        'repository_link': row['repository_link'],
                        'visibility': row['visibility']
                    })
            
            logger.info(f"Loaded {len(self.repositories)} repositories from {self.csv_file}")
            
        except Exception as e:
            logger.error(f"Error loading repositories from CSV: {e}")
    
    def check_git_credentials(self):
        """Check if Git credentials are configured."""
        try:
            # Check if git is available
            result = subprocess.run(['git', '--version'], capture_output=True, text=True, check=True)
            logger.info(f"Git version: {result.stdout.strip()}")
            
            # Check git user configuration
            user_name = subprocess.run(['git', 'config', '--global', 'user.name'], 
                                     capture_output=True, text=True, check=False)
            user_email = subprocess.run(['git', 'config', 'global', 'user.email'], 
                                      capture_output=True, text=True, check=False)
            
            if user_name.stdout.strip() and user_email.stdout.strip():
                logger.info(f"Git user configured: {user_name.stdout.strip()} <{user_email.stdout.strip()}>")
                return True
            else:
                logger.warning("Git user not configured globally")
                return False
                
        except subprocess.CalledProcessError:
            logger.error("Git is not available or not in PATH")
            return False
        except Exception as e:
            logger.error(f"Error checking Git credentials: {e}")
            return False
    
    def configure_git_for_https(self):
        """Configure Git for better HTTPS handling."""
        try:
            # Set longer timeout for HTTP operations
            subprocess.run(['git', 'config', '--global', 'http.postBuffer', '524288000'], 
                         capture_output=True, check=False)
            
            # Set longer timeout for HTTP operations
            subprocess.run(['git', 'config', '--global', 'http.lowSpeedLimit', '0'], 
                         capture_output=True, check=False)
            subprocess.run(['git', 'config', 'global', 'http.lowSpeedTime', '999999'], 
                         capture_output=True, check=False)
            
            # Disable SSL verification if needed (use with caution)
            # subprocess.run(['git', 'config', '--global', 'http.sslVerify', 'false'], 
            #              capture_output=True, check=False)
            
            logger.info("Configured Git for better HTTPS handling")
            return True
            
        except Exception as e:
            logger.warning(f"Could not configure Git HTTPS settings: {e}")
            return False
    
    def clone_repository_with_retry(self, repo_info, max_retries=3):
        """
        Clone a single repository with retry mechanism.
        
        Args:
            repo_info (dict): Repository information dictionary
            max_retries (int): Maximum number of retry attempts
            
        Returns:
            tuple: (success, repo_name, error_message)
        """
        repo_name = repo_info['repository_name']
        repo_link = repo_info['repository_link']
        team_name = repo_info['team_name']
        
        # Create team directory
        team_dir = self.output_dir / team_name
        team_dir.mkdir(exist_ok=True)
        
        # Check if repository already exists
        repo_path = team_dir / repo_name
        if repo_path.exists():
            logger.info(f"Repository {repo_name} already exists in {team_dir}, skipping...")
            return (True, repo_name, "Already exists")
        
        # Try different clone strategies
        strategies = [
            # Strategy 1: Standard HTTPS clone
            lambda: self._clone_https(repo_link, repo_path),
            # Strategy 2: HTTPS clone with depth 1 (shallow clone)
            lambda: self._clone_shallow(repo_link, repo_path),
            # Strategy 3: HTTPS clone with different user agent
            lambda: self._clone_with_custom_agent(repo_link, repo_path),
        ]
        
        for attempt in range(max_retries):
            for strategy_idx, strategy in enumerate(strategies):
                try:
                    logger.info(f"Attempt {attempt + 1}/{max_retries}, Strategy {strategy_idx + 1}: Cloning {repo_name} for team {team_name}...")
                    
                    success, error_msg = strategy()
                    if success:
                        logger.info(f"Successfully cloned {repo_name} using strategy {strategy_idx + 1}")
                        return (True, repo_name, None)
                    else:
                        logger.warning(f"Strategy {strategy_idx + 1} failed for {repo_name}: {error_msg}")
                        
                except Exception as e:
                    logger.warning(f"Strategy {strategy_idx + 1} failed with exception for {repo_name}: {e}")
                    continue
            
            # If all strategies failed, wait before retry
            if attempt < max_retries - 1:
                wait_time = (2 ** attempt) + random.uniform(0, 1)  # Exponential backoff with jitter
                logger.info(f"All strategies failed for {repo_name}, waiting {wait_time:.1f}s before retry...")
                time.sleep(wait_time)
        
        # All retries failed
        error_msg = f"All {max_retries} attempts failed for {repo_name}"
        logger.error(f"Failed to clone {repo_name} after {max_retries} attempts")
        return (False, repo_name, error_msg)
    
    def _clone_https(self, repo_link, repo_path):
        """Standard HTTPS clone."""
        try:
            result = subprocess.run(
                ['git', 'clone', repo_link, str(repo_path)],
                capture_output=True,
                text=True,
                check=True,
                timeout=600  # 10 minute timeout
            )
            return True, None
        except subprocess.CalledProcessError as e:
            return False, f"Git clone failed: {e.stderr.strip()}"
        except subprocess.TimeoutExpired:
            return False, "Clone operation timed out after 10 minutes"
        except Exception as e:
            return False, f"Unexpected error: {str(e)}"
    
    def _clone_shallow(self, repo_link, repo_path):
        """Shallow clone (depth 1) for faster cloning."""
        try:
            result = subprocess.run(
                ['git', 'clone', '--depth', '1', repo_link, str(repo_path)],
                capture_output=True,
                text=True,
                check=True,
                timeout=300  # 5 minute timeout for shallow clone
            )
            return True, None
        except subprocess.CalledProcessError as e:
            return False, f"Shallow clone failed: {e.stderr.strip()}"
        except subprocess.TimeoutExpired:
            return False, "Shallow clone operation timed out"
        except Exception as e:
            return False, f"Unexpected error in shallow clone: {str(e)}"
    
    def _clone_with_custom_agent(self, repo_link, repo_path):
        """Clone with custom user agent to avoid some GitHub restrictions."""
        try:
            # Set custom user agent
            env = os.environ.copy()
            env['GIT_HTTP_USER_AGENT'] = 'git/2.30.0'
            
            result = subprocess.run(
                ['git', 'clone', repo_link, str(repo_path)],
                capture_output=True,
                text=True,
                check=True,
                timeout=600,
                env=env
            )
            return True, None
        except subprocess.CalledProcessError as e:
            return False, f"Custom agent clone failed: {e.stderr.strip()}"
        except subprocess.TimeoutExpired:
            return False, "Custom agent clone operation timed out"
        except Exception as e:
            return False, f"Unexpected error in custom agent clone: {str(e)}"
    
    def clone_repository(self, repo_info):
        """Clone a single repository (wrapper for retry mechanism)."""
        return self.clone_repository_with_retry(repo_info)
    
    def clone_all_repositories(self):
        """Clone all repositories using thread pool for concurrent operations."""
        if not self.repositories:
            logger.error("No repositories to clone")
            return
        
        logger.info(f"Starting to clone {len(self.repositories)} repositories...")
        logger.info(f"Using {self.max_workers} concurrent workers (reduced for stability)")
        logger.info(f"Output directory: {self.output_dir.absolute()}")
        
        start_time = time.time()
        
        # Use ThreadPoolExecutor for concurrent cloning
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all clone tasks
            future_to_repo = {
                executor.submit(self.clone_repository, repo_info): repo_info 
                for repo_info in self.repositories
            }
            
            # Process completed tasks
            for future in as_completed(future_to_repo):
                repo_info = future_to_repo[future]
                try:
                    success, repo_name, error_msg = future.result()
                    if success:
                        if error_msg == "Already exists":
                            self.skipped_clones += 1
                        else:
                            self.successful_clones += 1
                    else:
                        self.failed_clones += 1
                        
                except Exception as e:
                    logger.error(f"Exception occurred while cloning {repo_info['repository_name']}: {e}")
                    self.failed_clones += 1
                
                # Add delay between clones to avoid rate limiting
                time.sleep(1)
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Log final results
        logger.info("=" * 60)
        logger.info("CLONING COMPLETED")
        logger.info("=" * 60)
        logger.info(f"Total repositories: {len(self.repositories)}")
        logger.info(f"Successfully cloned: {self.successful_clones}")
        logger.info(f"Skipped (already exists): {self.skipped_clones}")
        logger.info(f"Failed: {self.failed_clones}")
        logger.info(f"Total time: {duration:.2f} seconds")
        logger.info(f"Average time per repo: {duration/len(self.repositories):.2f} seconds")
        
        if self.failed_clones > 0:
            logger.warning(f"{self.failed_clones} repositories failed to clone. Check the logs for details.")
            logger.info("You can re-run the script to retry failed repositories.")
        
        # Create summary report
        self.create_summary_report()
    
    def create_summary_report(self):
        """Create a summary report of the cloning operation."""
        report_path = self.output_dir / "cloning_summary.txt"
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write("HACKATHON REPOSITORY CLONING SUMMARY\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Total repositories: {len(self.repositories)}\n")
                f.write(f"Successfully cloned: {self.successful_clones}\n")
                f.write(f"Skipped (already exists): {self.skipped_clones}\n")
                f.write(f"Failed: {self.failed_clones}\n\n")
                
                f.write("REPOSITORY STRUCTURE:\n")
                f.write("-" * 30 + "\n")
                for repo_info in self.repositories:
                    team_dir = self.output_dir / repo_info['team_name']
                    repo_path = team_dir / repo_info['repository_name']
                    status = "✅ Cloned" if repo_path.exists() else "❌ Failed"
                    f.write(f"{repo_info['team_name']}/{repo_info['repository_name']}: {status}\n")
            
            logger.info(f"Summary report created: {report_path}")
            
        except Exception as e:
            logger.error(f"Failed to create summary report: {e}")
    
    def verify_cloned_repositories(self):
        """Verify that all repositories were cloned successfully."""
        logger.info("Verifying cloned repositories...")
        
        verified_count = 0
        missing_count = 0
        
        for repo_info in self.repositories:
            team_dir = self.output_dir / repo_info['team_name']
            repo_path = team_dir / repo_info['repository_name']
            
            if repo_path.exists() and (repo_path / '.git').exists():
                verified_count += 1
            else:
                missing_count += 1
                logger.warning(f"Repository missing or incomplete: {repo_info['repository_name']}")
        
        logger.info(f"Verification complete: {verified_count} verified, {missing_count} missing")
        return verified_count, missing_count
    
    def retry_failed_repositories(self):
        """Retry cloning failed repositories."""
        if self.failed_clones == 0:
            logger.info("No failed repositories to retry")
            return
        
        logger.info(f"Retrying {self.failed_clones} failed repositories...")
        
        # Reset counters
        original_failed = self.failed_clones
        self.failed_clones = 0
        self.successful_clones = 0
        
        # Get list of failed repositories
        failed_repos = []
        for repo_info in self.repositories:
            team_dir = self.output_dir / repo_info['team_name']
            repo_path = team_dir / repo_info['repository_name']
            if not repo_path.exists() or not (repo_path / '.git').exists():
                failed_repos.append(repo_info)
        
        # Retry failed repositories
        for repo_info in failed_repos:
            success, repo_name, error_msg = self.clone_repository(repo_info)
            if success:
                self.successful_clones += 1
            else:
                self.failed_clones += 1
        
        logger.info(f"Retry complete: {self.successful_clones} recovered, {self.failed_clones} still failed")


def main():
    """Main function to run the repository cloning script."""
    print("🚀 Hackathon Repository Cloner (Improved)")
    print("=" * 45)
    
    try:
        # Check if CSV file exists
        if not os.path.exists('repository_links.csv'):
            print("❌ Error: repository_links.csv not found!")
            print("Please run quick_setup.py first to create repositories.")
            sys.exit(1)
        
        # Initialize cloner
        cloner = RepositoryCloner(
            csv_file='repository_links.csv',
            output_dir='repositories',
            max_workers=3  # Reduced for better stability
        )
        
        # Check Git credentials
        if not cloner.check_git_credentials():
            print("⚠️  Warning: Git credentials not configured. Some operations may fail.")
            response = input("Continue anyway? (y/N): ")
            if response.lower() != 'y':
                print("Aborting...")
                sys.exit(1)
        
        # Configure Git for better HTTPS handling
        cloner.configure_git_for_https()
        
        # Start cloning
        print(f"📁 Will clone {len(cloner.repositories)} repositories to 'repositories' directory")
        print(f"🔧 Using {cloner.max_workers} concurrent workers (reduced for stability)")
        print(f"⏱️  Estimated time: {len(cloner.repositories) * 45 / cloner.max_workers:.0f} seconds")
        print("🔄 Using multiple clone strategies and retry mechanisms")
        
        response = input("\nProceed with cloning? (Y/n): ")
        if response.lower() == 'n':
            print("Aborting...")
            sys.exit(0)
        
        print("\n🔄 Starting repository cloning...")
        cloner.clone_all_repositories()
        
        # Offer to retry failed repositories
        if cloner.failed_clones > 0:
            print(f"\n⚠️  {cloner.failed_clones} repositories failed to clone.")
            response = input("Would you like to retry failed repositories? (Y/n): ")
            if response.lower() != 'n':
                cloner.retry_failed_repositories()
        
        # Verify results
        print("\n🔍 Verifying cloned repositories...")
        verified, missing = cloner.verify_cloned_repositories()
        
        # Final summary
        print("\n" + "=" * 60)
        print("🎉 CLONING COMPLETED!")
        print("=" * 60)
        print(f"✅ Successfully cloned: {cloner.successful_clones}")
        print(f"⏭️  Skipped (already exists): {cloner.skipped_clones}")
        print(f"❌ Failed: {cloner.failed_clones}")
        print(f"🔍 Verified: {verified}")
        print(f"📁 Output directory: {cloner.output_dir.absolute()}")
        
        if cloner.failed_clones > 0:
            print(f"\n⚠️  {cloner.failed_clones} repositories still failed after retries.")
            print("Check the logs for details. You may need to:")
            print("1. Check your GitHub authentication")
            print("2. Verify repository access permissions")
            print("3. Check your network connection")
            print("4. Consider using SSH instead of HTTPS")
            sys.exit(1)
        else:
            print("\n🎊 All repositories cloned successfully!")
            print("Teams can now start working on their projects!")
            sys.exit(0)
            
    except KeyboardInterrupt:
        print("\n\n⏹️  Cloning interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
