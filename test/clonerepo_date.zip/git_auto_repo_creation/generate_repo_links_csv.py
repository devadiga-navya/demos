#!/usr/bin/env python3
"""
Repository Links CSV Generator

This script generates a CSV file with repository names and their GitHub links
for all teams in the hackathon.
"""

import os
import sys
import logging
import pandas as pd
from github import Github, GithubException
from config import *

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('generate_repo_links.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class RepoLinksGenerator:
    def __init__(self):
        """Initialize the repository links generator."""
        if not GITHUB_TOKEN:
            raise ValueError("GitHub token is required. Please set GITHUB_TOKEN environment variable.")
        
        self.github = Github(GITHUB_TOKEN)
        self.org = self.github.get_organization(GITHUB_ORG_NAME)
        
        # Validate GitHub connection
        try:
            self.github.get_user()
            logger.info(f"Successfully connected to GitHub as {self.github.get_user().login}")
        except GithubException as e:
            logger.error(f"Failed to connect to GitHub: {e}")
            raise
    
    def get_all_repositories(self):
        """Get all repositories in the organization."""
        try:
            repos = list(self.org.get_repos())
            logger.info(f"Found {len(repos)} repositories in organization")
            return repos
        except Exception as e:
            logger.error(f"Error getting repositories: {e}")
            return []
    
    def get_team_repositories(self):
        """Get repositories that match the team naming pattern."""
        try:
            all_repos = self.get_all_repositories()
            team_repos = []
            
            for repo in all_repos:
                # Skip the template repository
                if repo.name == TEMPLATE_REPO_NAME:
                    logger.info(f"Skipping template repository: {repo.name}")
                    continue
                
                # Check if repository follows the team naming pattern
                if repo.name.startswith(REPO_PREFIX):
                    team_repos.append(repo)
                    logger.info(f"Found team repository: {repo.name}")
            
            logger.info(f"Found {len(team_repos)} team repositories")
            return team_repos
            
        except Exception as e:
            logger.error(f"Error getting team repositories: {e}")
            return []
    
    def extract_team_name_from_repo(self, repo_name):
        """Extract team name from repository name."""
        if repo_name.startswith(REPO_PREFIX):
            team_name = repo_name[len(REPO_PREFIX):]
            # Convert from kebab-case back to readable format
            team_name = team_name.replace('-', ' ').title()
            return team_name
        return repo_name
    
    def generate_repo_links_csv(self, output_file="repository_links.csv"):
        """Generate CSV file with repository names and links."""
        try:
            logger.info("Generating repository links CSV file...")
            
            # Get team repositories
            team_repos = self.get_team_repositories()
            
            if not team_repos:
                logger.warning("No team repositories found")
                return False
            
            # Create data for CSV
            csv_data = []
            
            for repo in team_repos:
                team_name = self.extract_team_name_from_repo(repo.name)
                repo_link = repo.html_url
                
                csv_data.append({
                    'team_name': team_name,
                    'repository_name': repo.name,
                    'repository_link': repo_link,
                    'visibility': 'Private' if repo.private else 'Public'
                })
                
                logger.info(f"Added: {team_name} -> {repo.name} -> {repo_link}")
            
            # Create DataFrame and save to CSV
            df = pd.DataFrame(csv_data)
            df.to_csv(output_file, index=False)
            
            logger.info(f"Successfully generated CSV file: {output_file}")
            logger.info(f"File contains {len(csv_data)} repository entries")
            
            # Display the generated data
            print(f"\n📊 Generated CSV file: {output_file}")
            print(f"📋 Contains {len(csv_data)} repository entries:")
            print("\n" + "="*80)
            print(f"{'Team Name':<25} {'Repository':<30} {'Visibility':<10}")
            print("="*80)
            
            for _, row in df.iterrows():
                print(f"{row['team_name']:<25} {row['repository_name']:<30} {row['visibility']:<10}")
            
            print("="*80)
            print(f"\n💾 CSV file saved to: {os.path.abspath(output_file)}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to generate CSV file: {e}")
            return False
    
    def generate_detailed_csv(self, output_file="detailed_repository_info.csv"):
        """Generate detailed CSV with additional repository information."""
        try:
            logger.info("Generating detailed repository information CSV file...")
            
            # Get team repositories
            team_repos = self.get_team_repositories()
            
            if not team_repos:
                logger.warning("No team repositories found")
                return False
            
            # Create detailed data for CSV
            csv_data = []
            
            for repo in team_repos:
                team_name = self.extract_team_name_from_repo(repo.name)
                repo_link = repo.html_url
                
                # Get additional repository information
                try:
                    # Get collaborators count
                    collaborators = list(repo.get_collaborators())
                    collaborator_count = len(collaborators)
                    
                    # Get teams with access
                    teams = list(repo.get_teams())
                    team_count = len(teams)
                    
                    # Get creation date
                    created_at = repo.created_at.strftime('%Y-%m-%d %H:%M:%S') if repo.created_at else 'Unknown'
                    
                    # Get last updated date
                    updated_at = repo.updated_at.strftime('%Y-%m-%d %H:%M:%S') if repo.updated_at else 'Unknown'
                    
                except Exception as e:
                    logger.warning(f"Could not get detailed info for {repo.name}: {e}")
                    collaborator_count = 0
                    team_count = 0
                    created_at = 'Unknown'
                    updated_at = 'Unknown'
                
                csv_data.append({
                    'team_name': team_name,
                    'repository_name': repo.name,
                    'repository_link': repo_link,
                    'visibility': 'Private' if repo.private else 'Public',
                    'collaborators': collaborator_count,
                    'teams': team_count,
                    'created_at': created_at,
                    'last_updated': updated_at,
                    'description': repo.description or 'No description'
                })
                
                logger.info(f"Added detailed info: {team_name} -> {repo.name}")
            
            # Create DataFrame and save to CSV
            df = pd.DataFrame(csv_data)
            df.to_csv(output_file, index=False)
            
            logger.info(f"Successfully generated detailed CSV file: {output_file}")
            logger.info(f"File contains {len(csv_data)} repository entries with detailed information")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to generate detailed CSV file: {e}")
            return False


def main():
    """Main function to run the repository links generator."""
    try:
        generator = RepoLinksGenerator()
        
        # Generate basic CSV
        if generator.generate_repo_links_csv():
            print("✅ Basic CSV file generated successfully!")
        else:
            print("❌ Failed to generate basic CSV file")
            return False
        
        # Generate detailed CSV
        if generator.generate_detailed_csv():
            print("✅ Detailed CSV file generated successfully!")
        else:
            print("❌ Failed to generate detailed CSV file")
            return False
        
        print("\n🎉 All CSV files generated successfully!")
        print("📁 Files created:")
        print("   • repository_links.csv (basic info)")
        print("   • detailed_repository_info.csv (detailed info)")
        
        return True
        
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"❌ Error: {e}")
        return False


if __name__ == "__main__":
    success = main()
    if success:
        sys.exit(0)
    else:
        sys.exit(1)
