#!/usr/bin/env python3
"""
Repository Cloning Script

This script clones all repositories listed in repository_links.csv.
It supports both public and private repositories and provides progress tracking.
"""

import csv
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Dict, Optional
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('clone_repositories.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class RepositoryCloner:
    def __init__(self, csv_file: str, output_dir: str = "repositories"):
        """
        Initialize the repository cloner.
        
        Args:
            csv_file: Path to the CSV file containing repository information
            output_dir: Directory where repositories will be cloned
        """
        self.csv_file = csv_file
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Statistics
        self.total_repos = 0
        self.successful_clones = 0
        self.failed_clones = 0
        self.skipped_clones = 0
        
    def read_csv(self) -> List[Dict[str, str]]:
        """Read and parse the CSV file."""
        repositories = []
        
        try:
            with open(self.csv_file, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    repositories.append(row)
                    
            logger.info(f"Found {len(repositories)} repositories in {self.csv_file}")
            return repositories
            
        except FileNotFoundError:
            logger.error(f"CSV file not found: {self.csv_file}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Error reading CSV file: {e}")
            sys.exit(1)
    
    def check_git_installed(self) -> bool:
        """Check if git is installed and accessible."""
        try:
            subprocess.run(['git', '--version'], 
                         capture_output=True, check=True, text=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def check_repository_exists(self, team_name: str, repo_name: str) -> bool:
        """Check if repository already exists locally."""
        team_dir = self.output_dir / team_name
        repo_path = team_dir / repo_name
        return repo_path.exists() and (repo_path / '.git').exists()
    
    def clone_repository(self, repo_info: Dict[str, str]) -> bool:
        """
        Clone a single repository.
        
        Args:
            repo_info: Dictionary containing repository information
            
        Returns:
            bool: True if successful, False otherwise
        """
        team_name = repo_info['team_name']
        repo_name = repo_info['repository_name']
        repo_url = repo_info['repository_link']
        visibility = repo_info['visibility']
        
        logger.info(f"Cloning {repo_name} (Team: {team_name}, Visibility: {visibility})")
        
        # Check if already exists
        if self.check_repository_exists(team_name, repo_name):
            logger.info(f"Repository {repo_name} already exists, skipping...")
            self.skipped_clones += 1
            return True
        
        # Create team directory if it doesn't exist
        team_dir = self.output_dir / team_name
        team_dir.mkdir(exist_ok=True)
        
        # Clone repository
        try:
            clone_path = team_dir / repo_name
            
            # Use git clone command
            cmd = ['git', 'clone', repo_url, str(clone_path)]
            
            logger.info(f"Running: {' '.join(cmd)}")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=str(team_dir)
            )
            
            if result.returncode == 0:
                logger.info(f"Successfully cloned {repo_name}")
                self.successful_clones += 1
                return True
            else:
                logger.error(f"Failed to clone {repo_name}")
                logger.error(f"Error: {result.stderr}")
                self.failed_clones += 1
                return False
                
        except Exception as e:
            logger.error(f"Exception while cloning {repo_name}: {e}")
            self.failed_clones += 1
            return False
    
    def clone_all_repositories(self) -> None:
        """Clone all repositories from the CSV file."""
        # Check prerequisites
        if not self.check_git_installed():
            logger.error("Git is not installed or not accessible. Please install Git first.")
            sys.exit(1)
        
        # Read repositories from CSV
        repositories = self.read_csv()
        self.total_repos = len(repositories)
        
        if self.total_repos == 0:
            logger.warning("No repositories found in CSV file.")
            return
        
        logger.info(f"Starting to clone {self.total_repos} repositories...")
        logger.info(f"Output directory: {self.output_dir.absolute()}")
        
        # Clone each repository
        for i, repo_info in enumerate(repositories, 1):
            logger.info(f"Progress: {i}/{self.total_repos}")
            
            success = self.clone_repository(repo_info)
            
            # Add a small delay to avoid overwhelming the server
            if i < self.total_repos:
                time.sleep(1)
        
        # Print summary
        self.print_summary()
    
    def print_summary(self) -> None:
        """Print a summary of the cloning operation."""
        logger.info("=" * 50)
        logger.info("CLONING SUMMARY")
        logger.info("=" * 50)
        logger.info(f"Total repositories: {self.total_repos}")
        logger.info(f"Successfully cloned: {self.successful_clones}")
        logger.info(f"Failed clones: {self.failed_clones}")
        logger.info(f"Skipped (already exists): {self.skipped_clones}")
        logger.info(f"Success rate: {(self.successful_clones/self.total_repos)*100:.1f}%")
        logger.info("=" * 50)
        
        if self.failed_clones > 0:
            logger.warning(f"{self.failed_clones} repositories failed to clone. Check the log for details.")
        
        logger.info(f"All repositories have been cloned to: {self.output_dir.absolute()}")

def main():
    """Main function."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Clone all repositories from repository_links.csv"
    )
    parser.add_argument(
        '--csv', 
        default='repository_links.csv',
        help='Path to the CSV file (default: repository_links.csv)'
    )
    parser.add_argument(
        '--output', 
        default='repositories',
        help='Output directory for cloned repositories (default: repositories)'
    )
    
    args = parser.parse_args()
    
    # Create and run the cloner
    cloner = RepositoryCloner(args.csv, args.output)
    cloner.clone_all_repositories()

if __name__ == "__main__":
    main()
