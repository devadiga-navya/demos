#!/usr/bin/env python3
"""
Repository Visibility Changer Script

This script changes the visibility of repositories in the GitHub organization.
It can change repositories from private to public or vice versa.
"""

import os
import sys
import time
import logging
import pandas as pd
from github import Github, GithubException
from config import *

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('change_repository_visibility.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class RepositoryVisibilityChanger:
    def __init__(self):
        """Initialize the repository visibility changer."""
        if not GITHUB_TOKEN:
            raise ValueError("GitHub token is required. Please set GITHUB_TOKEN environment variable.")
        
        self.github = Github(GITHUB_TOKEN)
        self.org = self.github.get_organization(GITHUB_ORG_NAME)
        
        # Validate GitHub connection
        try:
            self.github.get_user()
            logger.info(f"Successfully connected to GitHub as {self.github.get_user().login}")
        except GithubException as e:
            logger.error(f"Failed to connect to GitHub: {e}")
            raise
    
    def get_repositories_by_prefix(self, prefix):
        """Get all repositories with a specific prefix."""
        try:
            repos = []
            for repo in self.org.get_repos():
                if repo.name.startswith(prefix):
                    repos.append(repo)
            return repos
        except Exception as e:
            logger.error(f"Error getting repositories with prefix '{prefix}': {e}")
            return []
    
    def change_repository_visibility(self, repo_name, make_public=True):
        """Change the visibility of a specific repository."""
        try:
            repo = self.org.get_repo(repo_name)
            
            current_visibility = "public" if not repo.private else "private"
            target_visibility = "public" if make_public else "private"
            
            if current_visibility == target_visibility:
                logger.info(f"Repository '{repo_name}' is already {current_visibility}")
                return True
            
            # Change repository visibility
            repo.edit(private=not make_public)
            logger.info(f"Successfully changed repository '{repo_name}' from {current_visibility} to {target_visibility}")
            return True
            
        except GithubException as e:
            if "Not Found" in str(e):
                logger.warning(f"Repository '{repo_name}' not found")
                return False
            else:
                logger.error(f"Failed to change visibility of repository '{repo_name}': {e}")
                return False
    
    def change_repositories_by_prefix(self, prefix, make_public=True):
        """Change visibility of all repositories with a specific prefix."""
        target_visibility = "public" if make_public else "private"
        logger.info(f"Changing repositories with prefix '{prefix}' to {target_visibility}")
        
        repos = self.get_repositories_by_prefix(prefix)
        if not repos:
            logger.warning(f"No repositories found with prefix '{prefix}'")
            return 0, 0
        
        # Show what will be changed
        logger.info(f"Found {len(repos)} repositories to change to {target_visibility}:")
        for repo in repos:
            current_visibility = "public" if not repo.private else "private"
            archived_status = " (ARCHIVED)" if repo.archived else ""
            logger.info(f"  - {repo.name} (currently {current_visibility}{archived_status})")
        
        # Ask for confirmation
        confirm = input(f"Are you sure you want to change {len(repos)} repositories to {target_visibility}? (type 'yes' to confirm): ")
        if confirm.lower() != 'yes':
            logger.info("Visibility change cancelled by user")
            return 0, 0
        
        successful = 0
        failed = 0
        
        for repo in repos:
            # Skip the template repository
            if repo.name == "hackathon_template":
                logger.info(f"Skipping template repository: {repo.name}")
                continue
                
            try:
                current_visibility = "public" if not repo.private else "private"
                if current_visibility == target_visibility:
                    logger.info(f"Repository '{repo.name}' is already {current_visibility}")
                    successful += 1
                else:
                    repo.edit(private=not make_public)
                    logger.info(f"Successfully changed repository '{repo.name}' to {target_visibility}")
                    successful += 1
            except Exception as e:
                logger.error(f"Failed to change visibility of repository '{repo.name}': {e}")
                failed += 1
            
            # Add delay to avoid rate limiting
            time.sleep(1)
        
        return successful, failed
    
    def list_repositories(self, prefix=None):
        """List repositories and their current visibility."""
        try:
            if prefix:
                repos = self.get_repositories_by_prefix(prefix)
                logger.info(f"Repositories with prefix '{prefix}':")
            else:
                repos = list(self.org.get_repos())
                logger.info("All repositories in organization:")
            
            for repo in repos:
                visibility = "public" if not repo.private else "private"
                archived_status = " (ARCHIVED)" if repo.archived else ""
                logger.info(f"  - {repo.name} ({visibility}{archived_status})")
            
            return len(repos)
            
        except Exception as e:
            logger.error(f"Error listing repositories: {e}")
            return 0
    
    def run(self, mode="prefix", prefix=None, specific_repos=None, make_public=True):
        """Main execution method."""
        target_visibility = "public" if make_public else "private"
        logger.info(f"Starting Repository Visibility Change Process...")
        logger.info(f"Target visibility: {target_visibility}")
        
        if mode == "prefix":
            if not prefix:
                logger.error("No prefix provided for prefix mode")
                return False
            successful, failed = self.change_repositories_by_prefix(prefix, make_public)
        elif mode == "specific":
            if not specific_repos:
                logger.error("No specific repositories provided")
                return False
            successful = 0
            failed = 0
            for repo_name in specific_repos:
                # Skip the template repository
                if repo_name == "hackathon_template":
                    logger.info(f"Skipping template repository: {repo_name}")
                    continue
                if self.change_repository_visibility(repo_name, make_public):
                    successful += 1
                else:
                    failed += 1
        elif mode == "list":
            count = self.list_repositories(prefix)
            logger.info(f"Found {count} repositories")
            return True
        else:
            logger.error(f"Unknown mode: {mode}")
            return False
        
        logger.info(f"Visibility change complete. Successful: {successful}, Failed: {failed}")
        
        if successful > 0:
            logger.info(f"Successfully changed {successful} repositories to {target_visibility}!")
            return True
        else:
            logger.error("No repositories were changed successfully!")
            return False


def main():
    """Main function to run the repository visibility changer."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Change GitHub repository visibility")
    parser.add_argument("--mode", choices=["prefix", "specific", "list"], 
                       default="prefix", help="Operation mode: prefix=change by prefix, specific=change specific repos, list=list repos")
    parser.add_argument("--prefix", help="Repository prefix to change")
    parser.add_argument("--repos", nargs="+", help="Specific repository names to change")
    parser.add_argument("--list-only", action="store_true", help="Only list repositories, don't change")
    parser.add_argument("--make-private", action="store_true", help="Change to private (default is public)")
    
    args = parser.parse_args()
    
    try:
        changer = RepositoryVisibilityChanger()
        
        if args.list_only:
            success = changer.run("list", args.prefix)
        else:
            make_public = not args.make_private
            success = changer.run(args.mode, args.prefix, args.repos, make_public)
        
        if success:
            target_visibility = "private" if args.make_private else "public"
            print("Repository visibility change completed successfully!")
            sys.exit(0)
        else:
            print("Repository visibility change failed. Check the logs for details.")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
