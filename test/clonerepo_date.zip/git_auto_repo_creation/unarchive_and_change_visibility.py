#!/usr/bin/env python3
"""
Repository Unarchive and Visibility Changer Script

This script first unarchives repositories and then changes their visibility
from private to public in the GitHub organization.
"""

import os
import sys
import time
import logging
import pandas as pd
from github import Github, GithubException
from config import *

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('unarchive_and_change_visibility.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class RepositoryUnarchiveAndVisibilityChanger:
    def __init__(self):
        """Initialize the repository unarchive and visibility changer."""
        if not GITHUB_TOKEN:
            raise ValueError("GitHub token is required. Please set GITHUB_TOKEN environment variable.")
        
        self.github = Github(GITHUB_TOKEN)
        self.org = self.github.get_organization(GITHUB_ORG_NAME)
        
        # Validate GitHub connection
        try:
            self.github.get_user()
            logger.info(f"Successfully connected to GitHub as {self.github.get_user().login}")
        except GithubException as e:
            logger.error(f"Failed to connect to GitHub: {e}")
            raise
    
    def get_repositories_by_prefix(self, prefix):
        """Get all repositories with a specific prefix."""
        try:
            repos = []
            for repo in self.org.get_repos():
                if repo.name.startswith(prefix):
                    repos.append(repo)
            return repos
        except Exception as e:
            logger.error(f"Error getting repositories with prefix '{prefix}': {e}")
            return []
    
    def unarchive_and_change_visibility(self, repo_name, make_public=True, rearchive=True):
        """Unarchive a repository, change its visibility, and optionally archive it again."""
        try:
            repo = self.org.get_repo(repo_name)
            
            current_visibility = "public" if not repo.private else "private"
            target_visibility = "public" if make_public else "private"
            archived_status = " (ARCHIVED)" if repo.archived else ""
            
            logger.info(f"Processing repository '{repo_name}' (currently {current_visibility}{archived_status})")
            
            # Step 1: Unarchive if archived
            if repo.archived:
                logger.info(f"Unarchiving repository '{repo_name}'...")
                repo.edit(archived=False)
                logger.info(f"Successfully unarchived repository '{repo_name}'")
                # Wait a moment for the change to take effect
                time.sleep(2)
            else:
                logger.info(f"Repository '{repo_name}' is not archived")
            
            # Step 2: Change visibility if needed
            if current_visibility != target_visibility:
                logger.info(f"Changing repository '{repo_name}' from {current_visibility} to {target_visibility}...")
                repo.edit(private=not make_public)
                logger.info(f"Successfully changed repository '{repo_name}' to {target_visibility}")
            else:
                logger.info(f"Repository '{repo_name}' is already {target_visibility}")
            
            # Step 3: Re-archive if requested
            if rearchive:
                logger.info(f"Re-archiving repository '{repo_name}'...")
                repo.edit(archived=True)
                logger.info(f"Successfully re-archived repository '{repo_name}'")
            
            return True
            
        except GithubException as e:
            if "Not Found" in str(e):
                logger.warning(f"Repository '{repo_name}' not found")
                return False
            else:
                logger.error(f"Failed to process repository '{repo_name}': {e}")
                return False
    
    def process_repositories_by_prefix(self, prefix, make_public=True, rearchive=True):
        """Process all repositories with a specific prefix."""
        target_visibility = "public" if make_public else "private"
        archive_status = " and re-archive" if rearchive else " (keep unarchived)"
        logger.info(f"Processing repositories with prefix '{prefix}' - unarchiving, changing to {target_visibility}{archive_status}")
        
        repos = self.get_repositories_by_prefix(prefix)
        if not repos:
            logger.warning(f"No repositories found with prefix '{prefix}'")
            return 0, 0
        
        # Show what will be processed
        logger.info(f"Found {len(repos)} repositories to process:")
        for repo in repos:
            current_visibility = "public" if not repo.private else "private"
            archived_status = " (ARCHIVED)" if repo.archived else ""
            logger.info(f"  - {repo.name} (currently {current_visibility}{archived_status})")
        
        # Ask for confirmation
        confirm = input(f"Are you sure you want to process {len(repos)} repositories? (type 'yes' to confirm): ")
        if confirm.lower() != 'yes':
            logger.info("Processing cancelled by user")
            return 0, 0
        
        successful = 0
        failed = 0
        
        for repo in repos:
            # Skip the template repository
            if repo.name == "hackathon_template":
                logger.info(f"Skipping template repository: {repo.name}")
                continue
                
            try:
                if self.unarchive_and_change_visibility(repo.name, make_public, rearchive):
                    successful += 1
                else:
                    failed += 1
            except Exception as e:
                logger.error(f"Failed to process repository '{repo.name}': {e}")
                failed += 1
            
            # Add delay to avoid rate limiting
            time.sleep(2)
        
        return successful, failed
    
    def list_repositories(self, prefix=None):
        """List repositories and their current status."""
        try:
            if prefix:
                repos = self.get_repositories_by_prefix(prefix)
                logger.info(f"Repositories with prefix '{prefix}':")
            else:
                repos = list(self.org.get_repos())
                logger.info("All repositories in organization:")
            
            for repo in repos:
                visibility = "public" if not repo.private else "private"
                archived_status = " (ARCHIVED)" if repo.archived else ""
                logger.info(f"  - {repo.name} ({visibility}{archived_status})")
            
            return len(repos)
            
        except Exception as e:
            logger.error(f"Error listing repositories: {e}")
            return 0
    
    def run(self, mode="prefix", prefix=None, specific_repos=None, make_public=True, rearchive=True):
        """Main execution method."""
        target_visibility = "public" if make_public else "private"
        archive_status = " and re-archive" if rearchive else " (keep unarchived)"
        logger.info(f"Starting Repository Unarchive and Visibility Change Process...")
        logger.info(f"Target visibility: {target_visibility}{archive_status}")
        
        if mode == "prefix":
            if not prefix:
                logger.error("No prefix provided for prefix mode")
                return False
            successful, failed = self.process_repositories_by_prefix(prefix, make_public, rearchive)
        elif mode == "specific":
            if not specific_repos:
                logger.error("No specific repositories provided")
                return False
            successful = 0
            failed = 0
            for repo_name in specific_repos:
                # Skip the template repository
                if repo_name == "hackathon_template":
                    logger.info(f"Skipping template repository: {repo_name}")
                    continue
                if self.unarchive_and_change_visibility(repo_name, make_public, rearchive):
                    successful += 1
                else:
                    failed += 1
        elif mode == "list":
            count = self.list_repositories(prefix)
            logger.info(f"Found {count} repositories")
            return True
        else:
            logger.error(f"Unknown mode: {mode}")
            return False
        
        logger.info(f"Processing complete. Successful: {successful}, Failed: {failed}")
        
        if successful > 0:
            logger.info(f"Successfully processed {successful} repositories!")
            return True
        else:
            logger.error("No repositories were processed successfully!")
            return False


def main():
    """Main function to run the repository unarchive and visibility changer."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Unarchive and change GitHub repository visibility")
    parser.add_argument("--mode", choices=["prefix", "specific", "list"], 
                       default="prefix", help="Operation mode: prefix=process by prefix, specific=process specific repos, list=list repos")
    parser.add_argument("--prefix", help="Repository prefix to process")
    parser.add_argument("--repos", nargs="+", help="Specific repository names to process")
    parser.add_argument("--list-only", action="store_true", help="Only list repositories, don't process")
    parser.add_argument("--make-private", action="store_true", help="Change to private (default is public)")
    parser.add_argument("--keep-unarchived", action="store_true", help="Keep repositories unarchived (default is to re-archive)")
    
    args = parser.parse_args()
    
    try:
        changer = RepositoryUnarchiveAndVisibilityChanger()
        
        if args.list_only:
            success = changer.run("list", args.prefix)
        else:
            make_public = not args.make_private
            rearchive = not args.keep_unarchived
            success = changer.run(args.mode, args.prefix, args.repos, make_public, rearchive)
        
        if success:
            target_visibility = "private" if args.make_private else "public"
            print("Repository processing completed successfully!")
            sys.exit(0)
        else:
            print("Repository processing failed. Check the logs for details.")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
