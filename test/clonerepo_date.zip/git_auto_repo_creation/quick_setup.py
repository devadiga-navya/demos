#!/usr/bin/env python3
"""
Quick Hackathon Setup Script

This script creates repositories and adds users using GitHub usernames.
Simple and reliable approach.
"""

import os
import sys
import time
import logging
import pandas as pd
import subprocess
from github import Github, GithubException
from config import *

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('quick_setup.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class QuickHackathonSetup:
    def __init__(self):
        """Initialize the quick setup."""
        if not GITHUB_TOKEN:
            raise ValueError("GitHub token is required. Please set GITHUB_TOKEN environment variable.")
        
        self.github = Github(GITHUB_TOKEN)
        self.org = self.github.get_organization(GITHUB_ORG_NAME)
        self.template_repo = None
        
        # Configure Git user for this script
        self.configure_git_user()
        
        # Validate GitHub connection
        try:
            self.github.get_user()
            logger.info(f"Successfully connected to GitHub as {self.github.get_user().login}")
        except GithubException as e:
            logger.error(f"Failed to connect to GitHub: {e}")
            raise
    
    def configure_git_user(self):
        """Configure Git user for commits made by this script."""
        try:
            script_user_name = os.getenv('SCRIPT_GIT_USER_NAME', 'Hackathon Organizer')
            script_user_email = os.getenv('SCRIPT_GIT_USER_EMAIL', 'organizer@hackathon.com')
            
            subprocess.run(['git', 'config', '--global', 'user.name', script_user_name], 
                         capture_output=True, check=False)
            subprocess.run(['git', 'config', '--global', 'user.email', script_user_email], 
                         capture_output=True, check=False)
            
            logger.info(f"Configured Git user: {script_user_name} <{script_user_email}>")
        except Exception as e:
            logger.warning(f"Could not configure Git user: {e}")
    
    def get_template_repository(self):
        """Get the template repository for creating new repos."""
        try:
            self.template_repo = self.org.get_repo(TEMPLATE_REPO_NAME)
            logger.info(f"Found template repository: {TEMPLATE_REPO_NAME}")
            return True
        except GithubException as e:
            logger.error(f"Template repository '{TEMPLATE_REPO_NAME}' not found: {e}")
            return False
    
    def check_organization_permissions(self):
        """Check what permissions the current user has in the organization."""
        try:
            current_user = self.github.get_user()
            logger.info(f"Current user: {current_user.login}")
            
            # Check organization membership
            try:
                membership = self.org.get_member(current_user.login)
                logger.info(f"Organization member: {current_user.login}")
            except GithubException as e:
                logger.warning(f"Could not get organization membership: {e}")
            
            # Check if user can create teams
            try:
                teams = list(self.org.get_teams())
                logger.info(f"Can access teams: {len(teams)} teams found")
            except GithubException as e:
                logger.warning(f"Cannot access teams: {e}")
            
            # Check if user can create repositories
            try:
                repos = list(self.org.get_repos())
                logger.info(f"Can access repositories: {len(repos)} repos found")
            except GithubException as e:
                logger.warning(f"Cannot access repositories: {e}")
                
        except Exception as e:
            logger.warning(f"Could not check organization permissions: {e}")
    
    def create_repository(self, team_name, leader_username):
        """Create a new repository for a team."""
        repo_name = f"{REPO_PREFIX}{team_name.lower().replace(' ', '-')}"
        
        logger.info(f"Creating repository '{repo_name}' for team '{team_name}'")
        
        try:
            # Check if repository already exists
            try:
                existing_repo = self.org.get_repo(repo_name)
                logger.warning(f"Repository '{repo_name}' already exists for team '{team_name}'")
                return existing_repo
            except GithubException:
                pass  # Repository doesn't exist, continue with creation
            
            # Create repository from template
            try:
                repo = self.org.create_repo_from_template(
                    repo_name,
                    self.template_repo,
                    description=f"{REPO_DESCRIPTION} for team {team_name}",
                    private=(REPO_VISIBILITY == 'private')
                )
                logger.info(f"Created repository '{repo_name}' from template for team '{team_name}'")
            except GithubException as template_error:
                logger.warning(f"Template creation failed: {template_error}")
                logger.info(f"Falling back to creating empty repository for team '{team_name}'")
                
                # Fallback: create empty repository
                repo = self.org.create_repo(
                    repo_name,
                    description=f"{REPO_DESCRIPTION} for team {team_name}",
                    private=(REPO_VISIBILITY == 'private'),
                    auto_init=True
                )
                logger.info(f"Created empty repository '{repo_name}' for team '{team_name}'")
            
            return repo
            
        except GithubException as e:
            logger.error(f"Failed to create repository '{repo_name}' for team '{team_name}': {e}")
            return None
    
    def add_user_to_organization(self, username, role="member"):
        """Add a user to the organization by username."""
        try:
            # Get user by username
            user = self.github.get_user(username)
            logger.info(f"Found user: {user.login}")
            
            # Check if user is already a member by trying to get them from members list
            try:
                members = list(self.org.get_members())
                user_is_member = any(member.login == user.login for member in members)
                if user_is_member:
                    logger.info(f"User {user.login} is already a member of the organization")
                    return True
                else:
                    logger.info(f"User {user.login} is not a member, will invite")
            except GithubException as e:
                logger.warning(f"Could not check existing members: {e}")
                logger.info(f"Will attempt to invite user {user.login}")
            
            # Try to invite user to organization
            try:
                logger.info(f"Attempting to invite user {user.login} with role: '{role}'")
                self.org.invite_user(user=user, role=role)
                logger.info(f"Invited user {user.login} to organization with role: {role}")
                return True
            except GithubException as e:
                error_msg = str(e).lower()
                if "already a member" in error_msg or "already exists" in error_msg:
                    logger.info(f"User {user.login} is already a member of the organization")
                    return True
                else:
                    logger.error(f"Failed to invite user {username} to organization: {e}")
                    return False
            
        except GithubException as e:
            logger.error(f"Failed to get user {username}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error adding user {username} to organization: {e}")
            return False
    
    def add_user_to_repository(self, repo, leader_username):
        """Add a user to a repository with comprehensive permissions for team management."""
        try:
            # Get user by username
            user = self.github.get_user(leader_username)
            
            # Add user to repository with 'admin' permission to allow team/collaborator management
            try:
                repo.add_to_collaborators(user.login, 'admin')
                logger.info(f"Added user {user.login} to repository {repo.name} with 'admin' permission")
                logger.info(f"User can manage teams and collaborators, but restricted from dangerous operations")
            except GithubException as e:
                logger.error(f"Failed to add user to repository: {e}")
                return False
            
            # Create a team for this repository if it doesn't exist
            team_name = f"team-{repo.name}"
            team = None
            
            try:
                # Try to get existing team
                team = self.org.get_team_by_slug(team_name)
                logger.info(f"Found existing team: {team_name}")
            except GithubException:
                # Create new team for this repository
                try:
                    logger.info(f"Creating team '{team_name}' for repository {repo.name}")
                    logger.info(f"Team name: {team_name}")
                    logger.info(f"Repository names: [{GITHUB_ORG_NAME}/{repo.name}]")
                    
                    team = self.org.create_team(
                        name=team_name,
                        permission='push'  # Team members get push access
                    )
                    # Add repository to team after creation
                    try:
                        team.add_to_repos(repo)
                        logger.info(f"Added repository {repo.name} to team {team_name}")
                    except GithubException as repo_error:
                        logger.warning(f"Could not add repository to team: {repo_error}")
                    logger.info(f"Created new team '{team_name}' for repository {repo.name}")
                except GithubException as team_error:
                    logger.warning(f"Could not create team '{team_name}': {team_error}")
                    logger.warning("Team creation failed, but repository setup will continue")
                    team = None
                except Exception as e:
                    logger.error(f"Unexpected error creating team: {type(e).__name__}: {e}")
                    logger.warning("Team creation failed, but repository setup will continue")
                    team = None
            
            # Add the leader to the team if team exists
            if team:
                try:
                    team.add_membership(user, role='maintainer')
                    logger.info(f"Added {user.login} as maintainer to team '{team_name}'")
                except GithubException as team_member_error:
                    logger.warning(f"Could not add {user.login} to team '{team_name}': {team_member_error}")
            else:
                logger.warning(f"No team created for repository {repo.name}, but repository setup completed")
            
            # Verify the user was added successfully
            try:
                # Check if user is in collaborators list
                collaborators = list(repo.get_collaborators())
                user_found = any(collab.login == user.login for collab in collaborators)
                if user_found:
                    logger.info(f"Verified: {user.login} is a collaborator on {repo.name}")
                    
                    # Apply restrictions to prevent dangerous operations
                    self.apply_repository_restrictions(repo)
                    
                    return True
                else:
                    logger.warning(f"User {user.login} not found in repository collaborators")
                    return False
            except GithubException as e:
                logger.error(f"Failed to verify user permissions on repository: {e}")
                return False
            
        except GithubException as e:
            logger.error(f"Failed to add user {leader_username} to repository {repo.name}: {e}")
            return False
    
    def apply_repository_restrictions(self, repo):
        """Apply restrictions to prevent dangerous operations by team leaders."""
        try:
            logger.info(f"Applying safety restrictions to repository {repo.name}")
            
            # Note: GitHub API doesn't allow restricting specific admin actions
            # But we can document the restrictions and set up monitoring
            
            # Set repository description to indicate restrictions
            current_desc = repo.description or ""
            if "RESTRICTED" not in current_desc:
                restricted_desc = f"{current_desc} [RESTRICTED: Team leaders cannot rename/delete/archive/change visibility]"
                try:
                    repo.edit(description=restricted_desc)
                    logger.info(f"Updated repository description with restrictions notice")
                except GithubException as e:
                    logger.warning(f"Could not update repository description: {e}")
            
            # Log the restrictions that are in place
            logger.info(f"Repository {repo.name} restrictions:")
            logger.info("- Team leaders have admin access for team/collaborator management")
            logger.info("- Manual restrictions: Cannot rename, delete, archive, or change visibility")
            logger.info("- These restrictions are enforced through organizational policies")
            
        except Exception as e:
            logger.warning(f"Could not apply repository restrictions: {e}")
    
    def process_teams_data(self):
        """Process teams data from Excel file and create repositories."""
        try:
            # Read Excel file
            df = pd.read_excel(EXCEL_FILE_PATH)
            logger.info(f"Loaded {len(df)} teams from {EXCEL_FILE_PATH}")
            
            # Check if we have usernames or need to use emails as usernames
            if 'leader_username' in df.columns:
                username_column = 'leader_username'
            else:
                username_column = LEADER_EMAIL_COLUMN
                logger.info("No 'leader_username' column found, using email column as usernames")
            
            # Validate required columns
            required_columns = [TEAM_NAME_COLUMN, username_column]
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns in Excel file: {missing_columns}")
            
            # Process each team
            successful_setups = 0
            failed_setups = 0
            
            for index, row in df.iterrows():
                try:
                    team_name = row[TEAM_NAME_COLUMN]
                    leader_username = row[username_column]
                    
                    logger.info(f"Processing team: {team_name} (Leader: {leader_username})")
                    
                    # Step 1: Add user to organization
                    logger.info(f"Adding {leader_username} to organization...")
                    org_success = self.add_user_to_organization(leader_username)
                    if org_success:
                        logger.info(f"Successfully added {leader_username} to organization")
                    else:
                        logger.warning(f"Failed to add {leader_username} to organization, continuing...")
                    
                    # Step 2: Create repository
                    repo = self.create_repository(team_name, leader_username)
                    if repo:
                        # Step 3: Add leader to repository
                        repo_success = self.add_user_to_repository(repo, leader_username)
                        if repo_success:
                            successful_setups += 1
                            logger.info(f"Successfully processed team '{team_name}'")
                        else:
                            # Even if team membership fails, repository was created successfully
                            successful_setups += 1
                            logger.warning(f"Repository created for team '{team_name}' but team membership had issues")
                    else:
                        failed_setups += 1
                        logger.error(f"Failed to create repository for team '{team_name}'")
                    
                    # Add delay to avoid rate limiting
                    time.sleep(1)
                    
                except Exception as e:
                    logger.error(f"Error processing team {team_name if 'team_name' in locals() else 'unknown'}: {e}")
                    logger.error(f"Full error details: {type(e).__name__}: {str(e)}")
                    logger.error(f"Error type: {type(e)}")
                    logger.error(f"Error args: {e.args}")
                    import traceback
                    logger.error(f"Traceback: {traceback.format_exc()}")
                    failed_setups += 1
                    continue
            
            logger.info(f"Processing complete. Successful: {successful_setups}, Failed: {failed_setups}")
            return successful_setups, failed_setups
            
        except FileNotFoundError:
            logger.error(f"Excel file not found: {EXCEL_FILE_PATH}")
            return 0, 0
        except Exception as e:
            logger.error(f"Error processing Excel file: {e}")
            return 0, 0
    
    def run(self):
        """Main execution method."""
        logger.info("Starting Quick Hackathon Setup Process...")
        
        # Check organization permissions
        self.check_organization_permissions()
        
        # Validate template repository
        if not self.get_template_repository():
            logger.error("Cannot proceed without template repository")
            return False
        
        # Process teams data
        successful, failed = self.process_teams_data()
        
        logger.info(f"Final Results: {successful} successful, {failed} failed")
        
        if successful > 0:
            logger.info(f"Successfully processed {successful} teams!")
            logger.info("Use generate_repo_links_csv.py to create CSV with repository links")
            
            # Log permission summary
            logger.info("Permission Summary:")
            logger.info("- Team leaders have 'admin' permission (can add collaborators, manage teams, push code)")
            logger.info("- Manual restrictions prevent: rename, delete, archive, change repository visibility")
            logger.info("- Each repository has a dedicated team for easier member management")
            
            return True
        else:
            logger.error("No teams were processed successfully!")
            return False


def main():
    """Main function to run the quick setup script."""
    try:
        setup = QuickHackathonSetup()
        success = setup.run()
        
        if success:
            print("SUCCESS: Quick setup completed successfully!")
            print("REPOSITORIES: Repositories created and users added!")
            print("\nPERMISSION DETAILS:")
            print("   - Team leaders have 'admin' permission")
            print("   - They can add/remove collaborators, manage team members, and push code")
            print("   - Manual restrictions prevent: rename, delete, archive, change visibility")
            print("   - Each repo has a dedicated team for easier management")
            print("\nTO GET REPOSITORY LINKS, run:")
            print("   python generate_repo_links_csv.py")
            sys.exit(0)
        else:
            print("ERROR: Setup failed. Check the logs for details.")
            print("SUGGESTION: Try using GitHub usernames in your Excel file.")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"ERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
