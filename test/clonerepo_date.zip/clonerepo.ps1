﻿param(
    [Parameter(Mandatory=$true)]
    [string]$Organization,
    
    [Parameter(Mandatory=$true)]
    [string]$Token,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDirectory = ".\archived-repos-new"
)

# Function to make GitHub API requests
function Invoke-GitHubAPI {
    param(
        [string]$Uri,
        [string]$Token
    )
    
    $headers = @{
        "Authorization" = "token $Token"
        "Accept" = "application/vnd.github.v3+json"
        "User-Agent" = "PowerShell-Script"
    }
    
    try {
        $response = Invoke-RestMethod -Uri $Uri -Headers $headers -Method Get
        return $response
    }
    catch {
        Write-Error "Failed to make API request to $Uri : $($_.Exception.Message)"
        return $null
    }
}

# Function to clone a repository
function Clone-Repository {
    param(
        [string]$CloneUrl,
        [string]$RepoName,
        [string]$OutputPath,
        [string]$Token
    )
    
    # Modify clone URL to include token for private repos
    $authenticatedUrl = $CloneUrl -replace "https://", "https://$Token@"
    
    Write-Host "Cloning $RepoName..." -ForegroundColor Yellow
    
    try {
        $cloneResult = git clone $authenticatedUrl "$OutputPath\$RepoName" 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ Successfully cloned $RepoName" -ForegroundColor Green
            return $true
        } else {
            Write-Host "✗ Failed to clone $RepoName : $cloneResult" -ForegroundColor Red
            return $false
        }
    }
    catch {
        Write-Host "✗ Error cloning $RepoName : $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Main script execution
Write-Host "Cloning private archived repositories from organization: $Organization" -ForegroundColor Cyan
Write-Host "Output directory: $OutputDirectory" -ForegroundColor Cyan

# Create output directory if it doesn't exist
if (!(Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    Write-Host "Created directory: $OutputDirectory" -ForegroundColor Green
}

# Check if git is available
try {
    git --version | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Git not found"
    }
}
catch {
    Write-Error "Git is not installed or not available in PATH. Please install Git first."
    exit 1
}

# Validate token by testing API access
Write-Host "Validating GitHub token..." -ForegroundColor Yellow
$testUrl = "https://api.github.com/user"
$userInfo = Invoke-GitHubAPI -Uri $testUrl -Token $Token

if ($null -eq $userInfo) {
    Write-Error "Failed to authenticate with GitHub. Please check your token."
    exit 1
}

Write-Host "✓ Authenticated as: $($userInfo.login)" -ForegroundColor Green

# Get all repositories from the organization
Write-Host "Fetching repositories from organization: $Organization..." -ForegroundColor Yellow

$allRepos = @()
$page = 1
$perPage = 100

do {
    $apiUrl = "https://api.github.com/orgs/$Organization/repos?page=$page&per_page=$perPage&type=all"
    $repos = Invoke-GitHubAPI -Uri $apiUrl -Token $Token
    
    if ($null -eq $repos) {
        Write-Error "Failed to fetch repositories from organization: $Organization"
        exit 1
    }
    
    $allRepos += $repos
    $page++
    
    Write-Host "Fetched $($repos.Count) repositories from page $($page - 1)..." -ForegroundColor Gray
    
} while ($repos.Count -eq $perPage)

Write-Host "Total repositories found: $($allRepos.Count)" -ForegroundColor Cyan

# Filter for private and archived repositories
$targetRepos = $allRepos | Where-Object { 
    $_.private -eq $true -and $_.archived -eq $true 
}

if ($targetRepos.Count -eq 0) {
    Write-Host "No private archived repositories found in organization: $Organization" -ForegroundColor Yellow
    exit 0
}

Write-Host "Found $($targetRepos.Count) private archived repositories:" -ForegroundColor Green

# Display the repositories that will be cloned
foreach ($repo in $targetRepos) {
    Write-Host "  - $($repo.name) (archived: $($repo.archived_at))" -ForegroundColor Gray
}

# Prompt for confirmation
$confirm = Read-Host "`nDo you want to proceed with cloning these $($targetRepos.Count) repositories? (y/N)"
if ($confirm -notmatch "^[Yy]") {
    Write-Host "Operation cancelled." -ForegroundColor Yellow
    exit 0
}

# Clone repositories
Write-Host "`nStarting clone operations..." -ForegroundColor Cyan

$successCount = 0
$failCount = 0

foreach ($repo in $targetRepos) {
    $cloneSuccess = Clone-Repository -CloneUrl $repo.clone_url -RepoName $repo.name -OutputPath $OutputDirectory -Token $Token
    
    if ($cloneSuccess) {
        $successCount++
    } else {
        $failCount++
    }
    
    # Small delay to avoid rate limiting
    Start-Sleep -Milliseconds 500
}

# Summary
Write-Host "`n" + "="*50 -ForegroundColor Cyan
Write-Host "Clone operation completed!" -ForegroundColor Cyan
Write-Host "Successfully cloned: $successCount repositories" -ForegroundColor Green
Write-Host "Failed to clone: $failCount repositories" -ForegroundColor Red
Write-Host "Output directory: $OutputDirectory" -ForegroundColor Cyan

if ($failCount -gt 0) {
    Write-Host "`nPlease check the error messages above for failed repositories." -ForegroundColor Yellow
}