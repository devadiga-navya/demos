﻿param(
    [Parameter(Mandatory=$true)]
    [string]$Organization,
    
    [Parameter(Mandatory=$true)]
    [string]$Token,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputDirectory = ".\archived-repos",
    
    [Parameter(Mandatory=$false)]
    [int]$DaysThreshold = 4
)

# Function to make GitHub API requests
function Invoke-GitHubAPI {
    param(
        [string]$Uri,
        [string]$Token
    )
    
    $headers = @{
        "Authorization" = "token $Token"
        "Accept" = "application/vnd.github.v3+json"
        "User-Agent" = "PowerShell-Script"
    }
    
    try {
        $response = Invoke-RestMethod -Uri $Uri -Headers $headers -Method Get
        return $response
    }
    catch {
        Write-Error "Failed to make API request to $Uri : $($_.Exception.Message)"
        return $null
    }
}

# Function to clone a repository
function Clone-Repository {
    param(
        [string]$CloneUrl,
        [string]$RepoName,
        [string]$OutputPath,
        [string]$Token
    )
    
    # Modify clone URL to include token for private repos
    $authenticatedUrl = $CloneUrl -replace "https://", "https://$Token@"
    
    Write-Host "Cloning $RepoName..." -ForegroundColor Yellow
    
    try {
        $cloneResult = git clone $authenticatedUrl "$OutputPath\$RepoName" 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ Successfully cloned $RepoName" -ForegroundColor Green
            return $true
        } else {
            Write-Host "✗ Failed to clone $RepoName : $cloneResult" -ForegroundColor Red
            return $false
        }
    }
    catch {
        Write-Host "✗ Error cloning $RepoName : $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Function to get the latest commit date for a repository
function Get-LastCommitDate {
    param(
        [string]$Organization,
        [string]$RepoName,
        [string]$Token
    )
    
    try {
        # Get the default branch first
        $repoUrl = "https://api.github.com/repos/$Organization/$RepoName"
        $repoDetails = Invoke-GitHubAPI -Uri $repoUrl -Token $Token
        
        if ($null -eq $repoDetails -or $null -eq $repoDetails.default_branch) {
            Write-Warning "Could not get default branch for $RepoName"
            return $null
        }
        
        # Get the latest commit from the default branch
        $commitsUrl = "https://api.github.com/repos/$Organization/$RepoName/commits?sha=$($repoDetails.default_branch)&per_page=1"
        $commits = Invoke-GitHubAPI -Uri $commitsUrl -Token $Token
        
        if ($null -eq $commits -or $commits.Count -eq 0) {
            Write-Warning "No commits found for $RepoName"
            return $null
        }
        
        return $commits[0].commit.committer.date
    }
    catch {
        Write-Warning "Error getting last commit date for $RepoName : $($_.Exception.Message)"
        return $null
    }
}

# Function to check if repository had a recent commit within the threshold
function Test-RecentCommit {
    param(
        [string]$CommitDate,
        [int]$DaysThreshold
    )
    
    if ([string]::IsNullOrEmpty($CommitDate)) {
        return $false
    }
    
    try {
        $commitDateTime = [DateTime]::Parse($CommitDate)
        $thresholdDate = (Get-Date).AddDays(-$DaysThreshold)
        
        return $commitDateTime -gt $thresholdDate
    }
    catch {
        Write-Warning "Could not parse commit date: $CommitDate"
        return $false
    }
}

# Function to safely format commit date for display
function Format-CommitDate {
    param(
        [string]$CommitDate
    )
    
    if ([string]::IsNullOrEmpty($CommitDate)) {
        return @{
            FormattedDate = "unknown"
            DaysAgo = "unknown"
            IsValid = $false
        }
    }
    
    try {
        $commitDateTime = [DateTime]::Parse($CommitDate)
        $daysAgo = [math]::Round(((Get-Date) - $commitDateTime).TotalDays, 1)
        return @{
            FormattedDate = $commitDateTime.ToString('yyyy-MM-dd HH:mm:ss')
            DaysAgo = $daysAgo
            IsValid = $true
        }
    }
    catch {
        return @{
            FormattedDate = "invalid format"
            DaysAgo = "unknown"
            IsValid = $false
        }
    }
}

# Main script execution
Write-Host "Cloning private archived repositories from organization: $Organization" -ForegroundColor Cyan
Write-Host "Filtering for repositories with commits within the last $DaysThreshold days" -ForegroundColor Cyan
Write-Host "Output directory: $OutputDirectory" -ForegroundColor Cyan

# Create output directory if it doesn't exist
if (!(Test-Path $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    Write-Host "Created directory: $OutputDirectory" -ForegroundColor Green
}

# Check if git is available
try {
    git --version | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Git not found"
    }
}
catch {
    Write-Error "Git is not installed or not available in PATH. Please install Git first."
    exit 1
}

# Validate token by testing API access
Write-Host "Validating GitHub token..." -ForegroundColor Yellow
$testUrl = "https://api.github.com/user"
$userInfo = Invoke-GitHubAPI -Uri $testUrl -Token $Token

if ($null -eq $userInfo) {
    Write-Error "Failed to authenticate with GitHub. Please check your token."
    exit 1
}

Write-Host "✓ Authenticated as: $($userInfo.login)" -ForegroundColor Green

# Get all repositories from the organization
Write-Host "Fetching repositories from organization: $Organization..." -ForegroundColor Yellow

$allRepos = @()
$page = 1
$perPage = 100

do {
    $apiUrl = "https://api.github.com/orgs/$Organization/repos?page=$page&per_page=$perPage&type=all"
    $repos = Invoke-GitHubAPI -Uri $apiUrl -Token $Token
    
    if ($null -eq $repos) {
        Write-Error "Failed to fetch repositories from organization: $Organization"
        exit 1
    }
    
    $allRepos += $repos
    $page++
    
    Write-Host "Fetched $($repos.Count) repositories from page $($page - 1)..." -ForegroundColor Gray
    
} while ($repos.Count -eq $perPage)

Write-Host "Total repositories found: $($allRepos.Count)" -ForegroundColor Cyan

# Filter for private and archived repositories
$archivedRepos = $allRepos | Where-Object { 
    $_.private -eq $true -and $_.archived -eq $true 
}

Write-Host "Found $($archivedRepos.Count) private archived repositories" -ForegroundColor Gray

if ($archivedRepos.Count -eq 0) {
    Write-Host "No private archived repositories found in organization: $Organization" -ForegroundColor Yellow
    exit 0
}

# Filter for repositories with recent commits within the threshold
$thresholdDate = (Get-Date).AddDays(-$DaysThreshold)
Write-Host "Filtering for repositories with commits after: $($thresholdDate.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Gray

$targetRepos = @()
$repoCount = 0

foreach ($repo in $archivedRepos) {
    $repoCount++
    Write-Host "Checking commit history for $($repo.name) ($repoCount/$($archivedRepos.Count))..." -ForegroundColor Gray
    
    $lastCommitDate = Get-LastCommitDate -Organization $Organization -RepoName $repo.name -Token $Token
    
    if ($null -ne $lastCommitDate -and $lastCommitDate -ne "" -and (Test-RecentCommit -CommitDate $lastCommitDate -DaysThreshold $DaysThreshold)) {
        # Create a custom object with safe commit date handling
        $repoWithCommitDate = [PSCustomObject]@{
            Name = $repo.name
            CloneUrl = $repo.clone_url
            CommitDate = $lastCommitDate
            OriginalRepo = $repo
        }
        
        $targetRepos += $repoWithCommitDate
        
        $dateInfo = Format-CommitDate -CommitDate $lastCommitDate
        if ($dateInfo.IsValid) {
            Write-Host "  ✓ $($repo.name) has recent commit ($($dateInfo.DaysAgo) days ago)" -ForegroundColor Green
        } else {
            Write-Host "  ✓ $($repo.name) has recent commit (date format issue)" -ForegroundColor Green
        }
    } else {
        $dateInfo = Format-CommitDate -CommitDate $lastCommitDate
        if ($dateInfo.IsValid) {
            Write-Host "  - $($repo.name) last commit too old ($($dateInfo.DaysAgo) days ago)" -ForegroundColor DarkGray
        } else {
            Write-Host "  - $($repo.name) could not determine last commit date" -ForegroundColor DarkGray
        }
    }
    
    # Small delay to avoid rate limiting when checking commits
    Start-Sleep -Milliseconds 200
}

if ($targetRepos.Count -eq 0) {
    Write-Host "`nNo private archived repositories found with commits within the last $DaysThreshold days." -ForegroundColor Yellow
    
    # Show the most recent commit from archived repos
    $mostRecentRepo = $null
    $mostRecentCommitDate = $null
    
    Write-Host "Checking for most recent commit among archived repositories..." -ForegroundColor Gray
    foreach ($repo in $archivedRepos | Select-Object -First 5) {  # Check first 5 to avoid too many API calls
        $commitDate = Get-LastCommitDate -Organization $Organization -RepoName $repo.name -Token $Token
        if ($null -ne $commitDate -and $commitDate -ne "") {
            try {
                $commitDateTime = [DateTime]::Parse($commitDate)
                if ($null -eq $mostRecentCommitDate -or $commitDateTime -gt $mostRecentCommitDate) {
                    $mostRecentCommitDate = $commitDateTime
                    $mostRecentRepo = $repo.name
                }
            }
            catch {
                # Ignore parsing errors for this summary
            }
        }
        Start-Sleep -Milliseconds 200
    }
    
    if ($null -ne $mostRecentRepo) {
        Write-Host "Most recent commit found: $mostRecentRepo on $($mostRecentCommitDate.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Gray
    }
    
    exit 0
}

Write-Host "`nFound $($targetRepos.Count) private archived repositories with commits within the last $DaysThreshold days:" -ForegroundColor Green

# Display the repositories that will be cloned - with safe date handling
$validRepos = @()
$invalidDateRepos = @()

foreach ($repo in $targetRepos) {
    $dateInfo = Format-CommitDate -CommitDate $repo.CommitDate
    
    if ($dateInfo.IsValid) {
        $validRepos += [PSCustomObject]@{
            Name = $repo.Name
            CommitDate = [DateTime]::Parse($repo.CommitDate)
            DisplayInfo = $dateInfo
            RepoObj = $repo
        }
    } else {
        $invalidDateRepos += $repo
    }
}

# Sort and display valid repositories
if ($validRepos.Count -gt 0) {
    $sortedValidRepos = $validRepos | Sort-Object CommitDate -Descending
    foreach ($repo in $sortedValidRepos) {
        Write-Host "  - $($repo.Name) (last commit: $($repo.DisplayInfo.FormattedDate), $($repo.DisplayInfo.DaysAgo) days ago)" -ForegroundColor Gray
    }
}

# Display repositories with date issues
if ($invalidDateRepos.Count -gt 0) {
    Write-Host "`nRepositories with commit date issues:" -ForegroundColor Yellow
    foreach ($repo in $invalidDateRepos) {
        Write-Host "  - $($repo.Name) (commit date: $($repo.CommitDate))" -ForegroundColor DarkYellow
    }
}

# Prompt for confirmation
$confirm = Read-Host "`nDo you want to proceed with cloning these $($targetRepos.Count) repositories? (y/N)"
if ($confirm -notmatch "^[Yy]") {
    Write-Host "Operation cancelled." -ForegroundColor Yellow
    exit 0
}

# Clone repositories
Write-Host "`nStarting clone operations..." -ForegroundColor Cyan

$successCount = 0
$failCount = 0

foreach ($repoObj in $targetRepos) {
    $cloneSuccess = Clone-Repository -CloneUrl $repoObj.CloneUrl -RepoName $repoObj.Name -OutputPath $OutputDirectory -Token $Token
    
    if ($cloneSuccess) {
        $successCount++
    } else {
        $failCount++
    }
    
    # Small delay to avoid rate limiting
    Start-Sleep -Milliseconds 500
}

# Summary
Write-Host "`n" + "="*50 -ForegroundColor Cyan
Write-Host "Clone operation completed!" -ForegroundColor Cyan
Write-Host "Successfully cloned: $successCount repositories" -ForegroundColor Green
Write-Host "Failed to clone: $failCount repositories" -ForegroundColor Red
Write-Host "Total archived repos found: $($archivedRepos.Count)" -ForegroundColor Gray
Write-Host "Repos matching criteria: $($targetRepos.Count)" -ForegroundColor Gray
Write-Host "Output directory: $OutputDirectory" -ForegroundColor Cyan

if ($failCount -gt 0) {
    Write-Host "`nPlease check the error messages above for failed repositories." -ForegroundColor Yellow
}